export default function Home() {
  return (
    <>
      <header className="topbar">
        <a className="brand" href="#top">DB LAB · Docker</a>
        <nav><a href="#instalar">Instalar</a><a href="#contentores">Contentores?</a><a href="#replicas">3 réplicas</a><a href="#mysql">MySQL</a><a href="#sharding">Sharding</a></nav>
      </header>

      <main id="top">
        <section className="hero">
          <div>
            <span className="eyebrow">Windows + macOS</span>
            <h1>Bases de dados distribuídas, passo a passo.</h1>
            <p className="lead">Um guião de aula para arrancar serviços, entrar nos contentores, testar replicação e explorar sharding.</p>
            <a className="cta" href="#instalar">Começar a aula <span>↓</span></a>
          </div>
          <div className="terminal" aria-label="Resumo dos serviços">
            <div className="lights"><i></i><i></i><i></i></div>
            <p><b>$</b> docker compose up -d</p>
            <p className="ok">✓ MySQL 8.4 LTS</p><p className="ok">✓ PHP + Apache 8.2</p><p className="ok">✓ Python 3.11</p><p className="ok">✓ MongoDB 7.0</p><p className="cursor">_</p>
          </div>
        </section>

        <section className="band"><div><strong>2</strong><span>cenários completos</span></div><div><strong>3</strong><span>réplicas por replica set</span></div><div><strong>1</strong><span>comando por exemplo</span></div></section>

        <section id="instalar" className="content-section">
          <div className="section-heading"><span>01</span><div><h2>Preparar o computador</h2><p>Instala apenas o Docker Desktop. O resto chega dentro dos contentores.</p></div></div>
          <div className="two-col">
            <article className="os-card"><div className="os-icon">⊞</div><h3>Windows</h3><ol><li>Instala o <a href="https://docs.docker.com/desktop/setup/install/windows-install/">Docker Desktop</a>.</li><li>Espera por “Engine running”.</li><li>No Explorador abre a pasta do projeto.</li><li>Na barra do caminho escreve <code>powershell</code>.</li></ol><p className="note">No terminal: <code>cd replica-set</code>.</p></article>
            <article className="os-card"><div className="os-icon apple">●</div><h3>macOS</h3><ol><li>Instala o <a href="https://docs.docker.com/desktop/setup/install/mac-install/">Docker Desktop</a>.</li><li>Abre o Docker e aguarda.</li><li>No Finder seleciona a pasta.</li><li>Botão direito → Serviços → Novo Terminal na Pasta.</li></ol><p className="note">No terminal: <code>cd replica-set</code>.</p></article>
          </div>
          <div className="command"><span>Teste rápido</span><code>docker version</code></div>
        </section>

        <section className="content-section" id="estrutura">
          <div className="section-heading"><span>02</span><div><h2>Estrutura do projeto</h2><p>Os caminhos do Compose ligam as pastas locais aos contentores.</p></div></div>
          <pre>{`docker-database-lab/
├── common/          SQL, Dockerfiles e exemplo MySQL
├── replica-set/     Compose, inicialização e exemplo sem sharding
├── sharded/         Compose, inicialização e exemplo com sharding
├── tutorial/        página HTML deste guião
├── .env.example     portas e credenciais de exemplo
└── README.md        resumo do projeto`}</pre>
          <p>A pasta principal pode ter outro nome. Se moveres as subpastas, tens de corrigir os caminhos <code>build.context</code> e <code>volumes</code>. O Compose também pode ter outro nome: <code>docker compose -f aula.yml up -d</code>.</p>
          <details className="compose-details"><summary>Mostrar docker-compose.yml explicado</summary><p><code>services</code> declara os contentores; <code>image</code> escolhe a imagem; <code>build</code> constrói um Dockerfile; <code>environment</code> passa configurações; <code>ports</code> liga portas do computador ao contentor; <code>volumes</code> conserva dados ou monta ficheiros; <code>depends_on</code> define dependências de arranque.</p></details>
          <div className="storage-guide"><h3>Dados, backups e scripts</h3><p><code>mysql_data:/var/lib/mysql</code> guarda a base num volume gerido pelo Docker. O volume persiste após <code>docker compose down</code>, mas não substitui um backup.</p><pre>{`mkdir backups
docker compose exec mysql sh -c "mysqldump -u root -prootpass school > /tmp/school.sql"
docker compose cp mysql:/tmp/school.sql ./backups/school.sql`}</pre><p>Coloca SQL de inicialização em <code>common/mysql/init</code>, com nomes como <code>002-dados.sql</code>. Coloca Python partilhado em <code>common/python</code> e exemplos específicos nas pastas <code>replica-set/examples</code> ou <code>sharded/examples</code>. Os nomes são livres; atualiza o volume no Compose para cada novo ficheiro Python.</p></div>
          <p className="note">Também seria possível executar estes comandos nos terminais próprios dos contentores dentro do Docker Desktop. O guião usa o terminal do sistema para manter o processo igual em Windows e macOS.</p>
        </section>

        <section className="content-section" id="contentores">
          <div className="section-heading"><span>03</span><div><h2>Vale a pena usar contentores?</h2><p>O código da aplicação mantém-se; o ambiente torna-se reproduzível.</p></div></div>
          <div className="pros-cons-site"><article><h3>Vantagens</h3><ul><li>Mesmas versões em Windows e macOS.</li><li>Serviços isolados do sistema.</li><li>Arranque e reposição simples.</li><li>Dados persistentes em volumes.</li><li>Menos diferenças entre computadores.</li></ul></article><article><h3>Desvantagens</h3><ul><li>Consome memória e disco.</li><li>Introduz redes, volumes e portas.</li><li>Pode colidir com portas ocupadas.</li><li>Windows antigos podem ter limitações.</li><li>Compose local não é produção multi-host.</li></ul></article></div>
          <h3>O mesmo Python, configurações diferentes</h3>
          <pre>{`connection = pymysql.connect(
    host=os.getenv("MYSQL_HOST", "mysql"),
    port=int(os.getenv("MYSQL_PORT", "3306")),
    user=os.getenv("MYSQL_USER", "student"),
    password=os.getenv("MYSQL_PASSWORD", "studentpass"),
    database=os.getenv("MYSQL_DATABASE", "school"),
)`}</pre>
          <div className="connection-site"><article><b>Dentro do Compose</b><code>MYSQL_HOST=mysql</code><code>MYSQL_PORT=3306</code></article><article><b>No computador</b><code>MYSQL_HOST=127.0.0.1</code><code>MYSQL_PORT=3306</code></article></div>
          <p className="note"><strong>Não é o mesmo IP.</strong> O nome <code>mysql</code> é resolvido pelo DNS interno do Docker. Fora dos contentores, <code>127.0.0.1</code> usa a porta publicada. Se a porta exterior passar para <code>13306</code>, só o programa exterior muda; dentro da rede Docker continua a ser <code>mysql:3306</code>.</p>
        </section>

        <section id="replicas" className="content-section dark-section">
          <div className="section-heading"><span>02</span><div><h2>MongoDB com três réplicas</h2><p>Um primary recebe as escritas; dois secondaries mantêm cópias atualizadas.</p></div></div>
          <div className="replica-map"><div className="mongo primary"><small>mongo1</small><b>PRIMARY</b></div><span>replica</span><div className="mongo"><small>mongo2</small><b>SECONDARY</b></div><span>replica</span><div className="mongo"><small>mongo3</small><b>SECONDARY</b></div></div>
          <div className="instruction-grid"><article><b>Arrancar</b><p><code>docker compose up -d --build</code></p></article><article><b>Entrar no primary</b><p><code>docker compose exec mongo1 mongosh</code></p></article><article><b>Entrar no secondary</b><p><code>docker compose exec mongo2 mongosh</code></p></article></div>
          <div className="lab-block"><h3><code>mongosh</code> é o cliente</h3><p><code>mongod</code> é o servidor que guarda os dados. <code>mongosh</code> liga-se ao servidor, envia instruções e mostra respostas; fechá-lo não para o MongoDB.</p><h3>Primary → secondary</h3><p>No <code>mongo1</code>: <code>db.hello().isWritablePrimary</code>, depois <code>use aula</code> e <code>db.mensagens.insertOne(&#123;texto:&quot;Olá&quot;&#125;)</code>.</p><p>No <code>mongo2</code>: <code>db.getMongo().setReadPref(&quot;secondary&quot;)</code>, <code>use aula</code> e <code>db.mensagens.find()</code>. A preferência é necessária porque a ligação começa preparada para ler do primary; não usamos o obsoleto <code>rs.secondaryOk()</code>.</p></div>
        </section>

        <section id="mysql" className="content-section">
          <div className="section-heading"><span>04</span><div><h2>MySQL no terminal</h2><p>Experimenta primeiro o cliente manualmente e só depois executa Python.</p></div></div>
          <div className="example-list"><article><div className="tag mysql">NO SISTEMA</div><h3>Cliente instalado no computador</h3><pre>mysql -h 127.0.0.1 -P 3306 -u student -p school</pre><p>Introduz <code>studentpass</code>. Esta opção requer o cliente <code>mysql</code> instalado.</p></article><article><div className="tag mongo-tag">NO CONTENTOR</div><h3>Cliente incluído na imagem</h3><pre>{`docker compose exec mysql bash
mysql -u root -p`}</pre><p>Introduz <code>rootpass</code>. O serviço chama-se <code>mysql</code>.</p></article></div>
          <pre>{`SHOW DATABASES;
USE school;
SHOW TABLES;
DESCRIBE students;
SELECT * FROM students;`}</pre>
          <h3>Executar diretamente e usar Python</h3><pre>{`docker compose exec mysql mysql -u student -p school
docker compose exec python python /workspace/mysql_example.py`}</pre>
        </section>

        <section id="sharding" className="content-section shard-section">
          <div className="section-heading"><span>04</span><div><h2>Dois shards, três coleções</h2><p>A terceira coleção é repartida pelo campo <code>campus</code>.</p></div></div>
          <h3>Visão geral: pode estar em vários computadores</h3><p>O cliente liga-se ao <code>mongos</code>, que consulta os config servers e encaminha a operação para o shard correto. Os shards podem residir em máquinas diferentes.</p>
          <figure className="site-figure"><img src="/mongodb-sharding-distribuido.png" alt="Cluster MongoDB distribuído por computadores diferentes"/><figcaption>Arquitetura geral de um cluster distribuído.</figcaption></figure>
          <h3>Neste laboratório: tudo num computador</h3><p>O Compose mantém todos os componentes numa rede Docker local, preservando dois shards e três réplicas por shard.</p>
          <figure className="site-figure"><img src="/mongodb-sharding-laboratorio-local.png" alt="Laboratório MongoDB com todos os contentores num computador"/><figcaption>Configuração local e regra norte/sul usada no exemplo.</figcaption></figure>
          <div className="routing"><div><code>collection_one</code><span>→</span><b>Shard 1</b></div><div><code>collection_two</code><span>→</span><b>Shard 2</b></div><div><code>collection_three: norte / sul</code><span>→</span><b>Shard 1 / Shard 2</b></div></div>
          <div className="warning"><b>Não existem cópias entre shards.</b><p>Na terceira coleção, <code>campus=norte</code> vai para o Shard 1 e <code>campus=sul</code> para o Shard 2.</p></div>
          <pre className="big-command">docker compose exec python python /workspace/mongo/mongo_sharding_example.py</pre>
          <div className="lab-block light"><h3>Entrar e ver os documentos</h3><pre>{`docker compose exec mongos mongosh
use school_sharded
show collections
db.collection_one.find({}, {_id:0}).pretty()
db.collection_two.find({}, {_id:0}).pretty()
db.collection_three.find({}, {_id:0}).pretty()`}</pre><p>O resultado mostra um documento nas duas primeiras coleções e os documentos <code>norte</code> e <code>sul</code> na terceira.</p><h3>Ver o encaminhamento</h3><p>Com <code>explain()</code>, <code>campus=norte</code> devolve <code>[&quot;shard1RS&quot;]</code> e <code>campus=sul</code> devolve <code>[&quot;shard2RS&quot;]</code>.</p></div>
          <details className="compose-details"><summary>Mostrar a configuração de sharding</summary><p><code>--configsvr</code> cria os config servers; <code>--shardsvr</code> cria membros de shard; <code>--replSet</code> agrupa as réplicas; <code>mongos --configdb</code> liga o router aos metadados; <code>cluster-init</code> executa o script que adiciona shards, chunks e zonas.</p></details>
        </section>

        <section id="ajuda" className="content-section"><div className="multihost"><h3>Colocar um shard noutro computador</h3><p>O Compose atual é local. Para distribuir: publica a porta sem <code>127.0.0.1</code>; substitui os nomes <code>shard2a/b/c</code> por DNS/IP reais em <code>rs.initiate()</code> e <code>sh.addShard()</code>; altera <code>--configdb</code> se os config servers forem remotos; e aponta <code>MONGO_URI</code> ao endereço real do <code>mongos</code>. Configura firewall, keyFile, autenticação e TLS. Compose sozinho não faz orquestração multi-host.</p></div></section>
      </main>
      <footer><b>DB LAB</b><span>Configuração educativa · não expor à Internet</span></footer>
    </>
  );
}
